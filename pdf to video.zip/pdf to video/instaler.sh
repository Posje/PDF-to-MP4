#!/usr/bin/bash

sudo apt install ffmpeg
sudo pip install argparse

chmod +x pdf_to_video.sh
